Starting with Mule 3, the examples now come pre-built as zip files in the 
examples directory, e.g. $MULE_HOME/bookstore/mule-example-bookstore.zip.  
To run them, simply start Mule by running $MULE_HOME/bin/mule and copy the zip 
file to the $MULE_HOME/apps directory.  For example-specific information, please 
see the README.txt file in each example directory.

All Mule examples can be built using Maven as a build tool:
    Maven http://maven.apache.org

Some examples also allow Ant support:
    Ant   http://ant.apache.org

If you are not familiar with either tool, you might want to use the pre-builti example
file. If the example allows it, Ant is simpler to install, configure and use, but you get more
functionality with Maven.

For details on what each example does, how to run it and build it you can check the
README file that comes inside the example directory.
