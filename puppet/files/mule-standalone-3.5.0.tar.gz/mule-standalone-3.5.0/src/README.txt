An export of the Mule source code is included in this directory for convenience.

If you wish to browse or work directly with the source code, please read the 
information at http://www.mulesoft.org/documentation/display/MULECDEV/Subversion
