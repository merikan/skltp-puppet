Prerequisites
=============
You need to ensure that a Java Runtime Environment, version 1.7 or newer, is 
installed on your system.

Installation
============
SmartGit itself does not need to be installed; just unpack it to your preferred
location and launch the bin/smartgit.sh script. It might be necessary to define
the SMARTGIT_JAVA_HOME environment variable pointing to the used Java home.

If you have further questions regarding the SmartGit on Linux, please ask in
our mailing list:

 http://www.syntevo.com/smartgit/community.html
 
--
Your SmartGit-team
www.syntevo.com/smartgit
