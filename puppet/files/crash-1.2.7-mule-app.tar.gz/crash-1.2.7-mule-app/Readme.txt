The Crsh is a shell for Java Content Repository that comes bundled as a war file to deploy in eXo Portal 2.5 or GateIn.
It provides a file system view of a repository.
Documentation can be found here on the project site http://code.google.com/p/crsh/wiki/Introduction.